// ConsoleApplication10.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/*Assignment 2: Create a Face Annotation Tool
Now that you have learnt how to use mouse for annotation with OpenCV, 
it's time to put your concepts to a test. In this assignment, 
you will create a GUI application which will let the user 
create a bounding box around a face present in 
the input image and save the cropped face automatically.*/

#include <iostream>
#include<opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include<opencv2/imgproc.hpp>
#include<opencv2/imgcodecs.hpp>
#include<opencv2/objdetect.hpp>
#include<cmath>
#include<string>

cv::Mat Images;
cv::Mat face;
cv::Rect Box;

bool Cropping=false;
bool drawing = false;


void DrawRect(int Action, int x, int y, int flag, void* userData) {
    if (Action == cv::EVENT_LBUTTONDOWN) {
        drawing = true;
        Cropping = false;

        Box.x = x;
        Box.y = y;

        Box.width = 0;
        Box.height = 0;


    }
    else if (Action == cv::EVENT_LBUTTONUP) {
        drawing = false;
        Box.width = x - Box.x;
        Box.height = y - Box.y;
        if (Box.width > 0 && Box.height > 0) {
            face = Images(Box);
            Cropping = true;
        }
    }
    else if (Action == cv::EVENT_MOUSEMOVE) {
        if (drawing)
        {
            // Set the box width and height to the mouse position minus the origin
            Box.width = x - Box.x;
            Box.height = y - Box.y;

        }
    }
}




int main()
{
    std::string Path = "./Sekiro.jpeg";
    Images = cv::imread(Path);
    if (Images.empty()) {
        std::cout << "something problem in getting Image";
    }
    cv::resize(Images, Images, cv::Size(800,720));
    cv::Mat image_Copy = Images.clone();
    cv::CascadeClassifier face_classifier;


    if (!face_classifier.load("./haarcascade_frontalface_default.xml")) {
        std::cout << "Something Wrong" << "\n";

    }
    
    std::vector<cv::Rect> faces;
    face_classifier.detectMultiScale(Images,faces);

    if (faces.size() > 0) {
        Box = faces[0];
        // Crop the face region from the image
        face = Images(Box);
        // Set the cropping flag to true
        Cropping = true;
    }
    cv::namedWindow("face_Anotation_tool");
    cv::setMouseCallback("face_Anotation_tool", DrawRect, NULL);


    while (true) {

        Images.copyTo(image_Copy);
        if (drawing) {
            cv::rectangle(image_Copy, Box, cv::Scalar(0, 255, 0), 5);


        }
        if (Cropping) {
            cv::imshow("Cropped", face);

        }
        cv::putText(image_Copy, "Click Captical S to save cropped Image", cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX,0.7, cv::Scalar(0, 255, 255), 2);
        cv::imshow("face_Anotation_tool", image_Copy);



        int key = cv::waitKey(10);

        if (key == 27)
        {

            break;
        }
        else if (key == 83) {
            if (Cropping) {
                cv::imwrite("./cropped_face.jpg", face);
                std::cout << "Image is Cropped" << "\n";
            }
        }
    }


    
    std::cout << "Hello World!\n";



}

